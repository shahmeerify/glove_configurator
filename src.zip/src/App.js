import React, { useState } from "react";
import { Canvas } from "@react-three/fiber";
import { GloveModel } from "./components/GloveModel";
import { ContactShadows, Environment, OrbitControls } from "@react-three/drei";
import { colorOptions, colorMesh, colorData, tabs } from "./components/constants";


export default function App() {
  const [currentTab, setCurrentTab] = useState(tabs[0]);
  const [rotationValue, setRotationValue] = useState(31.05);
  const [currentMesh, setCurrentMesh] = useState("binding");
  const [colors, setColors] = useState(colorData);

  const rotateLeft = () => {
    setRotationValue(
      (prevVal) => (prevVal - Math.PI / 2 + 2 * Math.PI) % (2 * Math.PI)
    );
  };

  const rotateRight = () => {
    setRotationValue((prevVal) => (prevVal + Math.PI / 2) % (2 * Math.PI));
  };

  const handleColorChange = (meshName, newColor) => {
    setColors((prevColors) => ({
      ...prevColors,
      [meshName]: newColor,
    }));
  };

  const handleTabChange = (tab) => {
    setCurrentTab(tab);
  };

  const handlePreviousMeshClick = () => {
    const currentMeshIndex = colorMesh.indexOf(currentMesh);
    const previousMeshIndex =
      currentMeshIndex !== -1
        ? (currentMeshIndex - 1 + colorMesh.length) % colorMesh.length
        : 0;
    setCurrentMesh(colorMesh[previousMeshIndex]);
  };

  const handleNextMeshClick = () => {
    const currentMeshIndex = colorMesh.indexOf(currentMesh);
    const nextMeshIndex =
      currentMeshIndex !== -1 ? (currentMeshIndex + 1) % colorMesh.length : 0;
    setCurrentMesh(colorMesh[nextMeshIndex]);
  };

  return (
    <div className="glove py-12">
      <div className="px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="md:col-span-7 xl:col-span-8">
            <div className="canvas-carousel sc-jWBwVP kufCep flickity-enabled">
              <div
                className="flickity-viewport"
                style={{ height: "752px", touchAction: "pan-y" }}
              >
                <div
                  className="flickity-slider"
                  style={{ left: "0px", transform: "translateX(0%)" }}
                >
                  <div
                    aria-selected="true"
                    className="is-selected"
                    style={{ position: "absolute", left: "0%" }}
                  >
                    <div
                      id="canvas--BASEBALL_FIELDING_PRO_44--BACK"
                      className="responsive-canvas-wrap sc-brqgnP hDShiW"
                      style={{ height: "752px" }}
                    >
                      <Canvas
                        shadows
                        dpr={[1, 2]}
                        width={750}
                        height={750}
                        className="sc-cMljjf jjRdFm lower-canvas"
                        style={{ width: "750px", height: "750px" }}
                      >
                        <ambientLight intensity={0.7} />
                        <directionalLight
                          intensity={1}
                          position={[10, 15, 10]}
                        />
                        <pointLight intensity={1} position={[-10, 10, -10]} />
                        <GloveModel rot={rotationValue} colors={colors} />
                        {/* <Environment preset="city" /> */}
                        <OrbitControls
                          minPolarAngle={Math.PI / 2}
                          maxPolarAngle={Math.PI / 2}
                          enableZoom={true}
                          enablePan={false}
                        />
                      </Canvas>
                    </div>
                  </div>
                </div>
                <button
                  onClick={rotateLeft}
                  className="flickity-button flickity-prev-next-button previous"
                  type="button"
                  aria-label="Previous"
                >
                  <svg className="flickity-button-icon" viewBox="0 0 100 100">
                    <path
                      d="M 10,50 L 60,100 L 70,90 L 30,50  L 70,10 L 60,0 Z"
                      className="arrow"
                    />
                  </svg>
                </button>
                <button
                  onClick={rotateRight}
                  className="flickity-button flickity-prev-next-button next"
                  type="button"
                  aria-label="Next"
                >
                  <svg className="flickity-button-icon" viewBox="0 0 100 100">
                    <path
                      d="M 10,50 L 60,100 L 70,90 L 30,50  L 70,10 L 60,0 Z"
                      className="arrow"
                      transform="translate(100, 100) rotate(180) "
                    />
                  </svg>
                </button>
              </div>
            </div>
          </div>
          <div className="md:col-span-5 xl:col-span-4">
            <div className="configurator-container">
              <div className="tab-buttons">
                {tabs.map((tab) => (
                  <button
                    key={tab}
                    className={`tab-button ${
                      currentTab === tab ? "active" : ""
                    }`}
                    onClick={() => handleTabChange(tab)}
                  >
                    {tab}
                  </button>
                ))}
              </div>
              {currentTab === tabs[0] && (
                <div className="Base">
                  <h3 className="tab-heading">Base Personalization</h3>
                  {/* Add your custom Base Personalization UI here */}
                </div>
              )}
              {currentTab === tabs[1] && (
                <div className="Color">
                  <h3 className="tab-heading">Color Customization</h3>
                  <div className="mesh-navigation">
                    <button
                      onClick={handlePreviousMeshClick}
                      className="nav-button"
                      disabled={colorMesh.indexOf(currentMesh) === 0}
                    >
                      {"< Previous Mesh"}
                    </button>
                    <button
                      onClick={handleNextMeshClick}
                      className="nav-button"
                      disabled={
                        colorMesh.indexOf(currentMesh) === colorMesh.length - 1
                      }
                    >
                      {"Next Mesh >"}
                    </button>
                  </div>
                  <div className="color-options">
                    <div className="mesh-label">
                      Current Mesh: {currentMesh}
                    </div>
                    {colorOptions.map((color) => (
                      <div
                        key={color}
                        className={`color-option ${
                          colors[currentMesh] === color ? "selected" : ""
                        }`}
                        style={{ backgroundColor: color }}
                        onClick={() => handleColorChange(currentMesh, color)}
                      />
                    ))}
                  </div>
                </div>
              )}
               {currentTab === tabs[2] && (
                <div className="Personalize">
                  <h3 className="tab-heading">Base Personalization</h3>
                  {/* Add your custom Base Personalization UI here */}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
