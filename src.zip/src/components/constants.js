
export const colorOptions = [
    "#1a1a1a",
    "#908f88",
    "#FFFFFF",
    "#FFEDCC",
    "#FEF043",
    "#EEA144",
    "#EE722F",
    "#FF6300",
    "#9B4E2B",
    "#694E3B",
    "#D21E1E",
    "#813D3D",
    "#F07693",
    "#58357D",
    "#262740",
    "#2143BF",
    "#07C9DE",
    "#334F30",
    "#A9DCC3",
  ];
  
  export const colorMesh = [
    "binding",
    "laces",
    "leather1",
    "leather2",
    "leather3",
    "leather4",
    "leather5",
    "leather6",
    "leather7",
    "leather8",
    "logo_01", //Webbing Logo
    "palm",
    "stiches",
    "webStyle",
    "welt",
    "wingtipPinky",
    "wingtipThumb",
    "wrist",
    // "logo04_replace",
    // "slice",
    // "blackPiece",
    // "logo_03",
    // "logo_02", //Wrist Logo
  ];

  export const colorData = {
    binding: "#f5f5f5",
    logo4_replace: "#808080", //Palm Logo
    logo_03: "#e0e0e0", //Side Logo
    palm: "#f8f8f8",
    slice: "#f8f8f8", //Extension of Palm to Back
    welt: "#e0e0e0", //Edgings
    blackPiece: "#f0f0f0", //Back Hole Cover
    leather1: "#f8f8f8",
    leather2: "#f8f8f8",
    leather3: "#f8f8f8",
    leather4: "#f8f8f8",
    leather5: "#f8f8f8",
    leather6: "#f8f8f8",
    leather7: "#f8f8f8",
    leather8: "#f8f8f8",
    wingtipThumb: "#f8f8f8",
    wingtipPinky: "#f8f8f8",
    laces: "#e0e0e0",
    logo_01: "#f0f0f0", //Webbing Logo
    stiches: "#808080",
    webStyle: "#f0f0f0",
    logo_02: "#C0C0C0", //Wrist Logo
    wrist: "#f8f8f8",
  };
  
  export const tabs = ["Base", "Color", "Personalize"];